"""A module for visualization with tensorboard
"""

from .writer import FileWriter, SummaryWriter
from .record_writer import RecordWriter
